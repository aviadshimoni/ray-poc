import numpy as np
from keras.applications import MobileNetV2
from keras.preprocessing import image
from keras.applications.mobilenet_v2 import preprocess_input, decode_predictions
from starlette.requests import Request
from typing import Dict
from ray import serve
from ray.serve.handle import RayServeDeploymentHandle
from ray.serve.http_adapters import json_request

model = MobileNetV2(weights='imagenet')


def preprocess_image(img):
    img = img.resize((224, 224))
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)
    return x


def get_top_3(image):
    input_tensor = preprocess_image(image)
    predictions = model.predict(input_tensor)
    decoded_predictions = decode_predictions(predictions, top=3)[0]
    labels = [label for (_, label, probability) in decoded_predictions]
    return labels


# Define a Ray Serve deployment.
@serve.deployment(route_prefix="/classify")
class ImageClassifier:
    def __init__(self):
        self.model = model

    async def __call__(self, request: Request) -> Dict:
        file_data = await request.form()
        image_file = file_data["image"].file
        img = image.load_img(image_file)
        prediction = get_top_3(img)
        return {"prediction": prediction}


# Deploy
class_predicted = ImageClassifier.bind(http_adapter=json_request)